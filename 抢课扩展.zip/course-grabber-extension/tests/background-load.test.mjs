import assert from "node:assert/strict";

const listeners = {};
const event = (name) => ({ addListener(fn) { listeners[name] = fn; } });
const localStore = new Map();
const sessionStore = new Map();

const storageArea = (store) => ({
  async get(keys) {
    const names = Array.isArray(keys) ? keys : [keys];
    return Object.fromEntries(names.filter(Boolean).map((name) => [name, store.get(name)]));
  },
  async set(values) {
    Object.entries(values).forEach(([key, value]) => store.set(key, value));
  }
});

globalThis.chrome = {
  action: { onClicked: event("action") },
  runtime: {
    onInstalled: event("installed"),
    onStartup: event("startup"),
    onMessage: event("message"),
    openOptionsPage: async () => {},
    sendMessage: async () => {}
  },
  alarms: {
    onAlarm: event("alarm"),
    clear: async () => true,
    create: async () => {}
  },
  storage: {
    local: storageArea(localStore),
    session: storageArea(sessionStore)
  },
  power: {
    requestKeepAwake() {},
    releaseKeepAwake() {}
  },
  notifications: { create: async () => "test" },
  tabs: {
    query: async () => [],
    update: async () => {}
  },
  windows: { update: async () => {} },
  scripting: { executeScript: async () => [] }
};

await import(`../background.js?test=${Date.now()}`);
await new Promise((resolve) => setTimeout(resolve, 20));

assert.equal(typeof listeners.action, "function");
assert.equal(typeof listeners.installed, "function");
assert.equal(typeof listeners.startup, "function");
assert.equal(typeof listeners.alarm, "function");
assert.equal(typeof listeners.message, "function");
assert.ok(localStore.has("courseGrabberSettings"));
assert.ok(localStore.has("courseGrabberTargets"));
assert.ok(sessionStore.has("courseGrabberRuntime"));

console.log("后台服务初始化测试通过");
