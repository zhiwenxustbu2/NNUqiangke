export const TIME_ZONE = "Asia/Shanghai";
export const DEFAULT_SCHEDULE = Object.freeze({
  enabled: false,
  start: "16:55:00",
  end: "17:15:00",
  prepare: "16:54:55",
  pollIntervalMs: 1000,
  timeZone: TIME_ZONE
});

export const CATEGORY_META = Object.freeze({
  TJKC: { label: "系统推荐课程", tabId: "aRecommendCourse", queryKind: "recommended", isMajor: "1" },
  FANKC: { label: "跨年级选课", tabId: "aProgramCourse", queryKind: "program", isMajor: "1" },
  FAWKC: { label: "跨专业选课", tabId: "aUnProgramCourse", queryKind: "program", isMajor: "1" },
  XGXK: { label: "博雅教育课程", tabId: "aPublicCourse", queryKind: "public", isMajor: "1" },
  CXKC: { label: "重修课程", tabId: "aRetakeCourse", queryKind: "program", isMajor: "1" },
  TYKC: { label: "体育课程", tabId: "aSportCourse", queryKind: "program", isMajor: "1" },
  FXKC: { label: "辅修课程", tabId: "aMinorCourse", queryKind: "program", isMajor: "0" },
  WZYKC: { label: "微专业课程", tabId: "aMicroCourse", queryKind: "program", isMajor: "0" }
});

export const TARGET_STATES = Object.freeze({
  PENDING: "pending",
  MONITORING: "monitoring",
  SUBMITTING: "submitting",
  SUCCESS: "success",
  BLOCKED: "blocked"
});

export const RUNTIME_MODES = Object.freeze({
  IDLE: "idle",
  DRY_RUN: "dry-run",
  MANUAL: "manual",
  SCHEDULED: "scheduled",
  STOPPING: "stopping"
});

export function createIdleRuntime() {
  return {
    mode: RUNTIME_MODES.IDLE,
    startedAt: null,
    stoppedAt: null,
    stopReason: "",
    activeTargetId: null,
    lastCheckAt: null,
    submitLock: false,
    errorCount: 0,
    backoffUntil: 0,
    nextIndex: 0,
    preparedForSchedule: false
  };
}

export function mergeSchedule(value = {}) {
  try {
    const schedule = validateSchedule(value.start || DEFAULT_SCHEDULE.start, value.end || DEFAULT_SCHEDULE.end);
    return {
      ...DEFAULT_SCHEDULE,
      ...value,
      ...schedule,
      enabled: Boolean(value.enabled),
      timeZone: TIME_ZONE
    };
  } catch {
    return { ...DEFAULT_SCHEDULE, enabled: false };
  }
}

export function getBjtParts(timestamp = Date.now()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  }).formatToParts(new Date(timestamp));
  return Object.fromEntries(parts.filter((item) => item.type !== "literal").map((item) => [item.type, item.value]));
}

export function bjtDateKey(timestamp = Date.now()) {
  const p = getBjtParts(timestamp);
  return `${p.year}-${p.month}-${p.day}`;
}

export function bjtSecondsOfDay(timestamp = Date.now()) {
  const p = getBjtParts(timestamp);
  return Number(p.hour) * 3600 + Number(p.minute) * 60 + Number(p.second);
}

export function parseTimeToSeconds(value) {
  const match = /^(\d{2}):(\d{2}):(\d{2})$/.exec(value || "");
  if (!match) {
    throw new Error(`无效时间：${value}`);
  }
  const [, h, m, s] = match.map(Number);
  if (h > 23 || m > 59 || s > 59) {
    throw new Error(`无效时间：${value}`);
  }
  return h * 3600 + m * 60 + s;
}

export function formatSecondsAsTime(value) {
  const seconds = ((Number(value) % 86400) + 86400) % 86400;
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;
  return [hours, minutes, remainingSeconds].map((item) => String(item).padStart(2, "0")).join(":");
}

export function derivePrepareTime(start, leadSeconds = 5) {
  return formatSecondsAsTime(parseTimeToSeconds(start) - leadSeconds);
}

export function validateSchedule(start, end) {
  const normalizedStart = formatSecondsAsTime(parseTimeToSeconds(start));
  const normalizedEnd = formatSecondsAsTime(parseTimeToSeconds(end));
  if (normalizedStart === normalizedEnd) {
    throw new Error("自动开始时间和结束时间不能相同");
  }
  return {
    start: normalizedStart,
    end: normalizedEnd,
    prepare: derivePrepareTime(normalizedStart),
    pollIntervalMs: DEFAULT_SCHEDULE.pollIntervalMs,
    timeZone: TIME_ZONE
  };
}

export function isInScheduleWindow(timestamp, schedule = DEFAULT_SCHEDULE) {
  const now = bjtSecondsOfDay(timestamp);
  const start = parseTimeToSeconds(schedule.start);
  const end = parseTimeToSeconds(schedule.end);
  return start <= end ? now >= start && now < end : now >= start || now < end;
}

export function nextBjtOccurrence(timeText, now = Date.now()) {
  const targetSeconds = parseTimeToSeconds(timeText);
  const currentSeconds = bjtSecondsOfDay(now);
  let deltaSeconds = targetSeconds - currentSeconds;
  if (deltaSeconds <= 0) {
    deltaSeconds += 24 * 3600;
  }
  return now + deltaSeconds * 1000;
}

export function backoffDelayMs(errorCount) {
  const seconds = [0, 2, 4, 8, 16, 30][Math.min(Math.max(errorCount, 0), 5)] || 30;
  return seconds * 1000;
}

export function pickNextTarget(targets, startIndex = 0) {
  if (!Array.isArray(targets) || targets.length === 0) {
    return { target: null, nextIndex: 0 };
  }
  for (let offset = 0; offset < targets.length; offset += 1) {
    const index = (startIndex + offset) % targets.length;
    const target = targets[index];
    if (![TARGET_STATES.SUCCESS, TARGET_STATES.BLOCKED, TARGET_STATES.SUBMITTING].includes(target.state)) {
      return { target, nextIndex: (index + 1) % targets.length };
    }
  }
  return { target: null, nextIndex: startIndex % targets.length };
}

export function allTargetsSuccessful(targets) {
  return Array.isArray(targets) && targets.length > 0 && targets.every((target) => target.state === TARGET_STATES.SUCCESS);
}

export function capacityDecision(data) {
  const selected = Number(data?.numberOfSelected ?? data?.numberOfFirstVolunteer ?? 0);
  const capacity = Number(data?.classCapacity ?? 0);
  if (!Number.isFinite(selected) || !Number.isFinite(capacity) || capacity <= 0) {
    return { available: false, selected: 0, capacity: 0, reason: "容量数据无效" };
  }
  if (data?.genderAllowed === false) {
    return { available: false, selected, capacity, reason: data.genderReason || "性别容量已满" };
  }
  return {
    available: selected < capacity,
    selected,
    capacity,
    reason: selected < capacity ? "可选" : "人数已满"
  };
}

export function sanitizeTargetForExport(target) {
  const {
    state: _state,
    lastCapacity: _lastCapacity,
    lastCheckedAt: _lastCheckedAt,
    lastMessage: _lastMessage,
    resolvedAt: _resolvedAt,
    ...safe
  } = target;
  return safe;
}

export function targetValidationError(target) {
  if (!target?.courseName || !target?.courseNumber || !target?.categoryCode) {
    return "课程信息不完整，请重新解析";
  }
  if (!target?.teachingClassId || !target?.teacherName || !target?.courseIndex) {
    return "必须指定老师和课序号";
  }
  if (target.hasTest === "1" && !target.testTeachingClassId) {
    return "该课程包含实验课，必须先指定实验班";
  }
  if (target.bookUnsupported) {
    return "网站要求选择教材订购方式，当前版本不会自动猜测";
  }
  return "";
}
