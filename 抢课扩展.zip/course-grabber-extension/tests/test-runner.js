import {
  TARGET_STATES,
  backoffDelayMs,
  capacityDecision,
  isInScheduleWindow,
  pickNextTarget,
  targetValidationError
} from "../core.js";

const tests = [];
const test = (name, fn) => tests.push({ name, fn });
const assert = (condition, message = "断言失败") => { if (!condition) throw new Error(message); };
const bjt = (text) => new Date(`${text}+08:00`).getTime();

test("自动时段边界", () => {
  const schedule = { start: "16:55:00", end: "17:15:00" };
  assert(!isInScheduleWindow(bjt("2026-08-24T16:54:59"), schedule));
  assert(isInScheduleWindow(bjt("2026-08-24T16:55:00"), schedule));
  assert(!isInScheduleWindow(bjt("2026-08-24T17:15:00"), schedule));
});

test("全局轮询跳过成功和提交中的目标", () => {
  const list = [
    { id: "1", state: TARGET_STATES.SUCCESS },
    { id: "2", state: TARGET_STATES.SUBMITTING },
    { id: "3", state: TARGET_STATES.PENDING }
  ];
  assert(pickNextTarget(list, 0).target.id === "3");
});

test("网络退避封顶 30 秒", () => {
  assert(backoffDelayMs(1) === 2000);
  assert(backoffDelayMs(5) === 30000);
  assert(backoffDelayMs(9) === 30000);
});

test("容量判断", () => {
  assert(capacityDecision({ numberOfSelected: 36, classCapacity: 70, genderAllowed: true }).available);
  assert(!capacityDecision({ numberOfSelected: 70, classCapacity: 70, genderAllowed: true }).available);
});

test("正式启动前必须指定具体班级", () => {
  const error = targetValidationError({ courseName: "测试课", courseNumber: "1", categoryCode: "TJKC" });
  assert(error.includes("老师和课序号"));
});

const results = document.getElementById("results");
for (const item of tests) {
  const li = document.createElement("li");
  try {
    item.fn();
    li.className = "pass";
    li.textContent = `通过：${item.name}`;
  } catch (error) {
    li.className = "fail";
    li.textContent = `失败：${item.name}（${error.message}）`;
  }
  results.append(li);
}
