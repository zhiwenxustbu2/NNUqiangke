import {
  CATEGORY_META,
  DEFAULT_SCHEDULE,
  RUNTIME_MODES,
  TARGET_STATES,
  allTargetsSuccessful,
  backoffDelayMs,
  capacityDecision,
  createIdleRuntime,
  isInScheduleWindow,
  mergeSchedule,
  nextBjtOccurrence,
  pickNextTarget,
  targetValidationError,
  validateSchedule
} from "./core.js";

const STORAGE_KEYS = Object.freeze({
  SETTINGS: "courseGrabberSettings",
  TARGETS: "courseGrabberTargets",
  LOGS: "courseGrabberLogs",
  ALERTS: "courseGrabberAlerts"
});

const SESSION_KEYS = Object.freeze({
  RUNTIME: "courseGrabberRuntime"
});

const ALARMS = Object.freeze({
  PREPARE: "course-grabber-prepare",
  START: "course-grabber-start",
  STOP: "course-grabber-stop",
  POLL: "course-grabber-poll"
});

const COURSE_PAGE_PATTERN = "https://xsxk.nnu.edu.cn/xsxkapp/sys/xsxkapp/*";
let pollInFlight = false;
let completionInFlight = false;

chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

chrome.runtime.onInstalled.addListener(async () => {
  await ensureDefaults();
  await stopRuntime("扩展已安装或更新，请重新启动监控", false);
  await rescheduleDailyAlarms();
  await syncAlertBadge();
});

chrome.runtime.onStartup.addListener(async () => {
  await ensureDefaults();
  const runtime = await getRuntime();
  if (runtime.mode === RUNTIME_MODES.MANUAL) {
    await stopRuntime("Chrome 已重启，手动监控不会自动恢复", false);
  }
  await rescheduleDailyAlarms();
  await syncAlertBadge();
  const settings = await getSettings();
  if (settings.enabled && isInScheduleWindow(Date.now(), settings)) {
    await startRuntime(RUNTIME_MODES.SCHEDULED, "浏览器启动后补执行自动监控");
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  void handleAlarm(alarm);
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  void handleMessage(message)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: safeMessage(error) }));
  return true;
});

async function handleMessage(message) {
  const type = message?.type;
  if (type === "GET_STATE") {
    const [settings, targets, runtime, logs, alerts] = await Promise.all([
      getSettings(),
      getTargets(),
      getRuntime(),
      getLogs(),
      getAlerts()
    ]);
    return { settings, targets, runtime, logs, alerts, categories: CATEGORY_META };
  }

  if (type === "SAVE_TARGETS") {
    const targets = Array.isArray(message.targets) ? message.targets : [];
    await chrome.storage.local.set({ [STORAGE_KEYS.TARGETS]: targets });
    await removeAlertsForMissingOrResolvedTargets(targets);
    broadcastStateChanged();
    return { targets };
  }

  if (type === "RESOLVE_COURSES") {
    const keywords = Array.from(new Set((message.keywords || []).map((item) => String(item).trim()).filter(Boolean)));
    if (keywords.length === 0) {
      throw new Error("请至少输入一个课程名或课程号");
    }
    const tab = await requireCourseTab(true);
    const result = await executeSiteAction(tab.id, "RESOLVE", { keywords });
    return { result };
  }

  if (type === "RESOLVE_TEST_CLASSES") {
    const tab = await requireCourseTab(true);
    const result = await executeSiteAction(tab.id, "RESOLVE_TEST", message.target || {});
    return { result };
  }

  if (type === "DRY_RUN") {
    return await runDryCheck();
  }

  if (type === "START_MANUAL") {
    return await startRuntime(RUNTIME_MODES.MANUAL, "用户手动启动");
  }

  if (type === "STOP") {
    await stopRuntime("用户手动停止", true);
    return {};
  }

  if (type === "SAVE_SCHEDULE") {
    const schedule = validateSchedule(String(message.start || ""), String(message.end || ""));
    const settings = { ...(await getSettings()), ...schedule };
    await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: settings });
    await rescheduleDailyAlarms();
    await addLog("info", `已保存每日自动时段：${formatScheduleRange(settings)}`);

    const runtime = await getRuntime();
    const inWindow = isInScheduleWindow(Date.now(), settings);
    if (runtime.mode === RUNTIME_MODES.SCHEDULED && !inWindow) {
      await stopRuntime("新的自动时段不包含当前时间", true);
    } else if (settings.enabled && runtime.mode === RUNTIME_MODES.IDLE && inWindow) {
      await startRuntime(RUNTIME_MODES.SCHEDULED, "保存时间后处于自动时段内，立即补启动");
    }
    return { settings: await getSettings() };
  }

  if (type === "ACK_ALERT") {
    const alerts = await getAlerts();
    const remaining = message.alertId ? alerts.filter((alert) => alert.id !== message.alertId) : [];
    await setAlerts(remaining);
    return { alerts: remaining };
  }

  if (type === "SET_AUTO_ENABLED") {
    const settings = await getSettings();
    settings.enabled = Boolean(message.enabled);
    await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: settings });
    await rescheduleDailyAlarms();
    await addLog("info", settings.enabled ? `已启用每日自动监控：${formatScheduleRange(settings)}` : "已停用每日自动监控");
    if (settings.enabled && isInScheduleWindow(Date.now(), settings)) {
      const runtime = await getRuntime();
      if (runtime.mode === RUNTIME_MODES.IDLE) {
        await startRuntime(RUNTIME_MODES.SCHEDULED, "在自动时段内启用，立即补启动");
      }
    }
    return { settings };
  }

  if (type === "RESET_RESULTS") {
    const targets = (await getTargets()).map((target) => ({
      ...target,
      state: TARGET_STATES.PENDING,
      lastCapacity: null,
      lastCheckedAt: null,
      lastMessage: "等待监控"
    }));
    await setTargets(targets);
    await setAlerts([]);
    await addLog("info", "已重置所有课程的运行结果");
    return { targets };
  }

  throw new Error(`不支持的消息类型：${type}`);
}

async function handleAlarm(alarm) {
  if (alarm.name === ALARMS.POLL) {
    await pollOnce();
    return;
  }

  const settings = await getSettings();
  if (alarm.name === ALARMS.PREPARE) {
    await scheduleNextAlarm(ALARMS.PREPARE, settings.prepare);
    if (!settings.enabled) return;
    const runtime = await getRuntime();
    if (runtime.mode !== RUNTIME_MODES.IDLE) return;
    try {
      const tab = await requireCourseTab(true);
      chrome.power.requestKeepAwake("system");
      await setRuntime({ ...runtime, preparedForSchedule: true });
      await addLog("info", `已准备自动监控页面：${tab.title || "选课"}`);
    } catch (error) {
      const message = safeMessage(error);
      await addLog("error", `自动监控准备失败：${message}`);
      await addAlert({ title: "选课监控准备失败", message });
      await safeNotify("选课监控准备失败", message);
    }
    return;
  }

  if (alarm.name === ALARMS.START) {
    await scheduleNextAlarm(ALARMS.START, settings.start);
    if (!settings.enabled) return;
    const runtime = await getRuntime();
    if (runtime.mode === RUNTIME_MODES.MANUAL) {
      await addLog("info", "手动监控正在运行，自动任务未重复启动");
      return;
    }
    try {
      await startRuntime(RUNTIME_MODES.SCHEDULED, "到达每日自动开始时间");
    } catch (error) {
      const message = safeMessage(error);
      await addLog("error", `自动监控启动失败：${message}`);
      await addAlert({ title: "自动监控启动失败", message });
      await safeNotify("自动监控启动失败", message);
    }
    return;
  }

  if (alarm.name === ALARMS.STOP) {
    await scheduleNextAlarm(ALARMS.STOP, settings.end);
    const runtime = await getRuntime();
    if (runtime.mode === RUNTIME_MODES.SCHEDULED) {
      await stopRuntime(`到达每日自动结束时间 ${settings.end}`, true);
    }
  }
}

async function ensureDefaults() {
  const stored = await chrome.storage.local.get(Object.values(STORAGE_KEYS));
  const updates = {};
  if (!stored[STORAGE_KEYS.SETTINGS]) updates[STORAGE_KEYS.SETTINGS] = { ...DEFAULT_SCHEDULE };
  if (!Array.isArray(stored[STORAGE_KEYS.TARGETS])) updates[STORAGE_KEYS.TARGETS] = [];
  if (!Array.isArray(stored[STORAGE_KEYS.LOGS])) updates[STORAGE_KEYS.LOGS] = [];
  if (!Array.isArray(stored[STORAGE_KEYS.ALERTS])) updates[STORAGE_KEYS.ALERTS] = [];
  if (Object.keys(updates).length > 0) await chrome.storage.local.set(updates);
  const session = await chrome.storage.session.get(SESSION_KEYS.RUNTIME);
  if (!session[SESSION_KEYS.RUNTIME]) await setRuntime(createIdleRuntime());
}

async function getSettings() {
  const value = await chrome.storage.local.get(STORAGE_KEYS.SETTINGS);
  return mergeSchedule(value[STORAGE_KEYS.SETTINGS]);
}

async function getTargets() {
  const value = await chrome.storage.local.get(STORAGE_KEYS.TARGETS);
  return Array.isArray(value[STORAGE_KEYS.TARGETS]) ? value[STORAGE_KEYS.TARGETS] : [];
}

async function setTargets(targets) {
  await chrome.storage.local.set({ [STORAGE_KEYS.TARGETS]: targets });
  broadcastStateChanged();
}

async function getLogs() {
  const value = await chrome.storage.local.get(STORAGE_KEYS.LOGS);
  return Array.isArray(value[STORAGE_KEYS.LOGS]) ? value[STORAGE_KEYS.LOGS] : [];
}

async function getAlerts() {
  const value = await chrome.storage.local.get(STORAGE_KEYS.ALERTS);
  return Array.isArray(value[STORAGE_KEYS.ALERTS]) ? value[STORAGE_KEYS.ALERTS] : [];
}

async function setAlerts(alerts) {
  await chrome.storage.local.set({ [STORAGE_KEYS.ALERTS]: alerts.slice(0, 50) });
  await syncAlertBadge(alerts);
  broadcastStateChanged();
}

async function getRuntime() {
  const value = await chrome.storage.session.get(SESSION_KEYS.RUNTIME);
  return { ...createIdleRuntime(), ...(value[SESSION_KEYS.RUNTIME] || {}) };
}

async function setRuntime(runtime) {
  await chrome.storage.session.set({ [SESSION_KEYS.RUNTIME]: runtime });
  broadcastStateChanged();
}

async function addLog(level, message, targetId = null) {
  const logs = await getLogs();
  logs.unshift({ id: crypto.randomUUID(), time: Date.now(), level, message: redact(message), targetId });
  await chrome.storage.local.set({ [STORAGE_KEYS.LOGS]: logs.slice(0, 300) });
  broadcastStateChanged();
}

async function addAlert({ title, message, targetId = null }) {
  const alerts = await getAlerts();
  const safeTitle = redact(title || "选课监控需要处理");
  const safeAlertMessage = redact(message || "发生未知错误");
  const duplicate = alerts.find((alert) => alert.targetId === targetId && alert.title === safeTitle && alert.message === safeAlertMessage);
  if (duplicate) return duplicate;
  const alert = {
    id: crypto.randomUUID(),
    time: Date.now(),
    level: "error",
    title: safeTitle,
    message: safeAlertMessage,
    targetId
  };
  await setAlerts([alert, ...alerts]);
  return alert;
}

async function clearAlertsForTarget(targetId) {
  if (!targetId) return;
  const alerts = await getAlerts();
  const remaining = alerts.filter((alert) => alert.targetId !== targetId);
  if (remaining.length !== alerts.length) await setAlerts(remaining);
}

async function removeAlertsForMissingOrResolvedTargets(targets) {
  const targetMap = new Map(targets.map((target) => [target.id, target]));
  const alerts = await getAlerts();
  const remaining = alerts.filter((alert) => {
    if (!alert.targetId) return true;
    const target = targetMap.get(alert.targetId);
    return Boolean(target && target.state === TARGET_STATES.BLOCKED);
  });
  if (remaining.length !== alerts.length) await setAlerts(remaining);
}

async function syncAlertBadge(alerts = null) {
  const currentAlerts = alerts || await getAlerts();
  await chrome.action.setBadgeBackgroundColor({ color: "#c53636" }).catch(() => {});
  await chrome.action.setBadgeText({ text: currentAlerts.length > 0 ? "!" : "" }).catch(() => {});
  await chrome.action.setTitle({
    title: currentAlerts.length > 0 ? `选课监控有 ${currentAlerts.length} 条待处理告警` : "打开选课监控助手"
  }).catch(() => {});
}

function broadcastStateChanged() {
  chrome.runtime.sendMessage({ type: "STATE_CHANGED" }).catch(() => {});
}

async function rescheduleDailyAlarms() {
  const settings = await getSettings();
  await Promise.all([
    chrome.alarms.clear(ALARMS.PREPARE),
    chrome.alarms.clear(ALARMS.START),
    chrome.alarms.clear(ALARMS.STOP)
  ]);
  if (!settings.enabled) return;
  await Promise.all([
    scheduleNextAlarm(ALARMS.PREPARE, settings.prepare),
    scheduleNextAlarm(ALARMS.START, settings.start),
    scheduleNextAlarm(ALARMS.STOP, settings.end)
  ]);
}

async function scheduleNextAlarm(name, timeText) {
  await chrome.alarms.create(name, {
    when: nextBjtOccurrence(timeText),
    persistAcrossSessions: true
  });
}

async function startRuntime(mode, reason) {
  await ensureDefaults();
  const current = await getRuntime();
  if ([RUNTIME_MODES.MANUAL, RUNTIME_MODES.SCHEDULED].includes(current.mode)) {
    return { runtime: current, alreadyRunning: true };
  }

  const settings = await getSettings();
  if (mode === RUNTIME_MODES.SCHEDULED && !isInScheduleWindow(Date.now(), settings)) {
    throw new Error("当前不在自动监控时段内");
  }

  let targets = await getTargets();
  if (targets.length === 0) throw new Error("还没有配置目标课程");
  const invalid = targets.map((target) => ({ target, error: targetValidationError(target) })).filter((item) => item.error);
  if (invalid.length > 0) {
    throw new Error(`${invalid[0].target.courseName || "目标课程"}：${invalid[0].error}`);
  }

  const tab = await requireCourseTab(true);
  const ping = await executeSiteAction(tab.id, "PING", {});
  if (!ping.ready) throw new Error(ping.message || "选课页面未登录或尚未加载完成");

  targets = targets.map((target) => target.state === TARGET_STATES.SUCCESS ? target : {
    ...target,
    state: String(target.isChoose) === "1" ? TARGET_STATES.SUCCESS : TARGET_STATES.PENDING,
    lastMessage: String(target.isChoose) === "1" ? "网站显示该班级已经选中" : "等待检测"
  });
  await setTargets(targets);

  if (allTargetsSuccessful(targets)) {
    if (settings.enabled) {
      settings.enabled = false;
      await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: settings });
      await rescheduleDailyAlarms();
    }
    await addLog("info", "所有目标课程都已成功，不需要再次启动监控");
    await safeNotify("无需启动监控", "所有目标课程都已成功");
    return { runtime: await getRuntime(), allSuccessful: true };
  }

  const runtime = {
    ...createIdleRuntime(),
    mode,
    startedAt: Date.now(),
    activeTargetId: null,
    preparedForSchedule: mode === RUNTIME_MODES.SCHEDULED
  };
  await setRuntime(runtime);
  chrome.power.requestKeepAwake("system");
  await chrome.alarms.clear(ALARMS.POLL);
  await chrome.alarms.create(ALARMS.POLL, {
    delayInMinutes: 1 / 60,
    periodInMinutes: 1 / 60,
    persistAcrossSessions: false
  });
  await addLog("info", `${mode === RUNTIME_MODES.MANUAL ? "手动" : "自动"}监控已启动：${reason}`);
  await safeNotify(
    "选课监控已启动",
    mode === RUNTIME_MODES.MANUAL ? "手动监控正在运行" : `自动监控将运行至 ${settings.end}`
  );
  void pollOnce();
  return { runtime };
}

async function stopRuntime(reason, notifyUser) {
  await chrome.alarms.clear(ALARMS.POLL);
  chrome.power.releaseKeepAwake();
  const previous = await getRuntime();
  const runtime = { ...createIdleRuntime(), stoppedAt: Date.now(), stopReason: reason };
  await setRuntime(runtime);
  if (previous.mode !== RUNTIME_MODES.IDLE) {
    await addLog("info", `监控已停止：${reason}`);
    if (notifyUser) await safeNotify("选课监控已停止", reason);
  }
}

async function finalizeSuccessfulRun() {
  if (completionInFlight) return true;
  const targets = await getTargets();
  if (!allTargetsSuccessful(targets)) return false;
  const runtime = await getRuntime();
  if (![RUNTIME_MODES.MANUAL, RUNTIME_MODES.SCHEDULED].includes(runtime.mode)) return true;

  completionInFlight = true;
  try {
    await chrome.alarms.clear(ALARMS.POLL);
    chrome.power.releaseKeepAwake();
    await setRuntime({ ...createIdleRuntime(), stoppedAt: Date.now(), stopReason: "全部目标课程已成功" });

    const settings = await getSettings();
    if (settings.enabled) {
      settings.enabled = false;
      await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: settings });
    }
    await rescheduleDailyAlarms();
    await addLog("success", "全部目标课程已成功，监控和每日自动任务已关闭");
    await safeNotify("全部选课成功", "所有目标课程均已成功，监控已自动关闭");
    return true;
  } finally {
    completionInFlight = false;
  }
}

async function pollOnce() {
  if (pollInFlight) return;
  pollInFlight = true;
  try {
    let runtime = await getRuntime();
    if (![RUNTIME_MODES.MANUAL, RUNTIME_MODES.SCHEDULED].includes(runtime.mode)) return;
    const settings = await getSettings();
    if (runtime.mode === RUNTIME_MODES.SCHEDULED && !isInScheduleWindow(Date.now(), settings)) {
      await stopRuntime("已离开每日自动监控时段", true);
      return;
    }
    if (runtime.backoffUntil > Date.now()) return;

    let targets = await getTargets();
    const pending = targets.filter((target) => ![TARGET_STATES.SUCCESS, TARGET_STATES.BLOCKED].includes(target.state));
    if (pending.length === 0) {
      if (!await finalizeSuccessfulRun()) {
        await stopRuntime("没有可继续监控的目标", true);
      }
      return;
    }

    const picked = pickNextTarget(targets, runtime.nextIndex);
    if (!picked.target) return;
    runtime = {
      ...runtime,
      activeTargetId: picked.target.id,
      nextIndex: picked.nextIndex,
      lastCheckAt: Date.now()
    };
    await setRuntime(runtime);

    const tab = await requireCourseTab(false);
    const result = await executeSiteAction(tab.id, "CAPACITY", picked.target);
    if (!result.ok) {
      if (result.fatal) {
        await blockTarget(picked.target.id, result.message || "页面状态异常");
        if (result.code === "LOGIN_REQUIRED") await stopRuntime(result.message || "登录已失效", true);
      } else {
        await recordTransientError(result.message || "容量查询失败");
      }
      return;
    }

    runtime = { ...runtime, errorCount: 0, backoffUntil: 0 };
    await setRuntime(runtime);
    const decision = capacityDecision(result.data);
    targets = await getTargets();
    const index = targets.findIndex((target) => target.id === picked.target.id);
    if (index < 0) return;
    const previousCapacity = targets[index].lastCapacity;
    targets[index] = {
      ...targets[index],
      state: TARGET_STATES.MONITORING,
      lastCapacity: { selected: decision.selected, capacity: decision.capacity },
      lastCheckedAt: Date.now(),
      lastMessage: decision.reason
    };
    await setTargets(targets);
    if (!previousCapacity || previousCapacity.selected !== decision.selected || previousCapacity.capacity !== decision.capacity) {
      await addLog("info", `${targets[index].courseName} [${targets[index].courseIndex}]：${decision.selected}/${decision.capacity} ${decision.reason}`, targets[index].id);
    }

    if (decision.available) {
      await submitTarget(tab.id, targets[index]);
    }
  } catch (error) {
    const message = safeMessage(error);
    if (/未找到已登录的选课页面|无法连接选课页面/.test(message)) {
      const runtime = await getRuntime();
      await addLog("error", `监控已停止：${message}`);
      await addAlert({ title: "选课页面不可用", message, targetId: runtime.activeTargetId });
      await safeNotify("选课页面不可用", message);
      await stopRuntime(message, false);
    } else {
      await recordTransientError(message);
    }
  } finally {
    pollInFlight = false;
  }
}

async function submitTarget(tabId, target) {
  let runtime = await getRuntime();
  if (runtime.submitLock) return;
  runtime = { ...runtime, submitLock: true, activeTargetId: target.id };
  await setRuntime(runtime);
  await updateTarget(target.id, { state: TARGET_STATES.SUBMITTING, lastMessage: "正在提交选课" });
  await addLog("info", `${target.courseName} [${target.courseIndex}] 发现名额，开始提交`, target.id);

  try {
    const submit = await executeSiteAction(tabId, "SUBMIT", target);
    if (!submit.ok) {
      if (submit.retryable) {
        await updateTarget(target.id, { state: TARGET_STATES.PENDING, lastMessage: submit.message || "提交暂未成功，继续监控" });
      } else {
        await blockTarget(target.id, submit.message || "提交失败");
      }
      return;
    }
    if (submit.alreadySelected) {
      await commitTargetSuccess(target, "网站显示该班级已经选中", `${target.courseName} [${target.courseIndex}] 已经在已选课程中`);
      return;
    }

    for (let attempt = 0; attempt < 10; attempt += 1) {
      const status = await executeSiteAction(tabId, "SUBMIT_STATUS", {});
      if (String(status.code) === "1") {
        await commitTargetSuccess(target, "选课成功", `${target.courseName} [${target.courseIndex}] 选课成功`);
        return;
      }
      if (String(status.code) === "-1") {
        const message = status.message || "学校系统返回选课失败";
        if (/容量|已满|稍后|繁忙|处理中/.test(message)) {
          await updateTarget(target.id, { state: TARGET_STATES.PENDING, lastMessage: `${message}，继续监控` });
        } else {
          await blockTarget(target.id, message);
        }
        return;
      }
      await wait(1000);
    }
    await updateTarget(target.id, { state: TARGET_STATES.PENDING, lastMessage: "提交结果查询超时，继续监控" });
    await addLog("warning", `${target.courseName} 提交结果查询超时`, target.id);
  } catch (error) {
    await updateTarget(target.id, { state: TARGET_STATES.PENDING, lastMessage: `提交异常：${safeMessage(error)}` });
    await addLog("error", `${target.courseName} 提交异常：${safeMessage(error)}`, target.id);
  } finally {
    runtime = await getRuntime();
    await setRuntime({ ...runtime, submitLock: false });
  }
}

async function commitTargetSuccess(target, lastMessage, logMessage) {
  await updateTarget(target.id, {
    state: TARGET_STATES.SUCCESS,
    lastMessage,
    succeededAt: Date.now()
  });

  // 成功状态提交后，后续日志、告警和通知失败都不能让课程回到待抢状态。
  try {
    await clearAlertsForTarget(target.id);
    await addLog("success", logMessage, target.id);
    const finalized = await finalizeSuccessfulRun();
    if (!finalized) {
      await safeNotify("选课成功", `${target.courseName} [${target.courseIndex}] ${target.teacherName}`);
    }
  } catch (error) {
    await addLog("warning", `${target.courseName} 已确认成功，但完成提醒异常：${safeMessage(error)}`, target.id).catch(() => {});
  }
}

async function runDryCheck() {
  const targets = await getTargets();
  if (targets.length === 0) throw new Error("还没有配置目标课程");
  for (const target of targets) {
    const error = targetValidationError(target);
    if (error) throw new Error(`${target.courseName || "目标课程"}：${error}`);
  }
  const tab = await requireCourseTab(true);
  const originalRuntime = await getRuntime();
  await setRuntime({ ...createIdleRuntime(), mode: RUNTIME_MODES.DRY_RUN, startedAt: Date.now() });
  const checked = [];
  try {
    for (const target of targets) {
      const result = await executeSiteAction(tab.id, "CAPACITY", target);
      if (!result.ok) {
        checked.push({ id: target.id, ok: false, message: result.message });
        await updateTarget(target.id, { lastMessage: `演练失败：${result.message}`, lastCheckedAt: Date.now() });
        continue;
      }
      const decision = capacityDecision(result.data);
      checked.push({ id: target.id, ok: true, ...decision });
      await updateTarget(target.id, {
        lastCapacity: { selected: decision.selected, capacity: decision.capacity },
        lastCheckedAt: Date.now(),
        lastMessage: `演练：${decision.reason}`
      });
      await addLog("info", `演练检查 ${target.courseName} [${target.courseIndex}]：${decision.selected}/${decision.capacity} ${decision.reason}`, target.id);
    }
    return { checked };
  } finally {
    await setRuntime({ ...createIdleRuntime(), stoppedAt: Date.now(), stopReason: "演练完成" });
    if (originalRuntime.mode !== RUNTIME_MODES.IDLE) await setRuntime(originalRuntime);
  }
}

async function recordTransientError(message) {
  const runtime = await getRuntime();
  const errorCount = runtime.errorCount + 1;
  const delay = backoffDelayMs(errorCount);
  await setRuntime({ ...runtime, errorCount, backoffUntil: Date.now() + delay });
  await addLog("warning", `临时错误（${Math.round(delay / 1000)} 秒后重试）：${message}`);
  if (errorCount === 5) await safeNotify("选课监控连续失败", `${message}；将继续按退避策略重试`);
}

async function updateTarget(id, patch) {
  const targets = await getTargets();
  const index = targets.findIndex((target) => target.id === id);
  if (index < 0) return;
  targets[index] = { ...targets[index], ...patch };
  await setTargets(targets);
}

async function blockTarget(id, message) {
  const target = (await getTargets()).find((item) => item.id === id);
  await updateTarget(id, { state: TARGET_STATES.BLOCKED, lastMessage: message, blockedAt: Date.now() });
  await addLog("error", `目标已停止：${message}`, id);
  await addAlert({
    title: target ? `${target.courseName} [${target.courseIndex}] 已停止` : "目标课程已停止",
    message,
    targetId: id
  });
  await safeNotify("目标课程已停止", target ? `${target.courseName}：${message}` : message);
}

async function requireCourseTab(focus) {
  const tabs = await chrome.tabs.query({ url: [COURSE_PAGE_PATTERN] });
  const tab = tabs
    .filter((item) => item.id && item.url?.includes("grablessons.do"))
    .sort((a, b) => Number(b.active) - Number(a.active))[0];
  if (!tab?.id) {
    throw new Error("未找到已登录的选课页面，请先在 Chrome 中打开学校选课页");
  }
  if (focus) {
    if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
    await chrome.tabs.update(tab.id, { active: true });
  }
  return tab;
}

async function executeSiteAction(tabId, action, payload) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: siteBridge,
    args: [action, payload]
  });
  if (!results?.[0]) throw new Error("无法连接选课页面");
  return results[0].result;
}

/*
 * 此函数由 Chrome 注入选课页面主执行环境。它不得引用外部变量，
 * 也不得返回令牌、学号等敏感数据。
 */
async function siteBridge(action, payload) {
  const categoryMeta = {
    TJKC: { label: "系统推荐课程", tabId: "aRecommendCourse", queryKind: "recommended", isMajor: "1" },
    FANKC: { label: "跨年级选课", tabId: "aProgramCourse", queryKind: "program", isMajor: "1" },
    FAWKC: { label: "跨专业选课", tabId: "aUnProgramCourse", queryKind: "program", isMajor: "1" },
    XGXK: { label: "博雅教育课程", tabId: "aPublicCourse", queryKind: "public", isMajor: "1" },
    CXKC: { label: "重修课程", tabId: "aRetakeCourse", queryKind: "program", isMajor: "1" },
    TYKC: { label: "体育课程", tabId: "aSportCourse", queryKind: "program", isMajor: "1" },
    FXKC: { label: "辅修课程", tabId: "aMinorCourse", queryKind: "program", isMajor: "0" },
    WZYKC: { label: "微专业课程", tabId: "aMicroCourse", queryKind: "program", isMajor: "0" }
  };

  const failure = (code, message, fatal = false, retryable = false) => ({ ok: false, code, message, fatal, retryable });
  const parseSession = (name) => {
    try {
      return JSON.parse(sessionStorage.getItem(name) || "null");
    } catch {
      return null;
    }
  };
  const fromDeferred = (request) => new Promise((resolve, reject) => {
    if (!request || typeof request.done !== "function") {
      reject(new Error("网站接口未加载"));
      return;
    }
    request.done(resolve);
    if (typeof request.fail === "function") request.fail((_xhr, status, error) => reject(new Error(error || status || "网络请求失败")));
  });
  const normalizeText = (value) => String(value ?? "").trim();
  const studentInfo = parseSession("studentInfo");
  const currentCampus = parseSession("currentCampus");
  const currentBatch = parseSession("currentBatch") || {};
  const bookParam = parseSession("bookParam") || {};
  const tokenReady = Boolean(sessionStorage.getItem("token"));

  if (!studentInfo?.code || !studentInfo?.electiveBatch?.code || !currentCampus?.code || !tokenReady) {
    return failure("LOGIN_REQUIRED", "选课登录状态已失效，请重新登录并刷新页面", true);
  }

  if (action === "PING") {
    return { ready: true, title: document.title, message: "选课页面已连接" };
  }

  const buildQueryParam = (keyword, categoryCode) => {
    const meta = categoryMeta[categoryCode];
    const data = {
      studentCode: studentInfo.code,
      campus: currentCampus.code,
      electiveBatchCode: studentInfo.electiveBatch.code,
      isMajor: meta.isMajor,
      teachingClassType: categoryCode,
      checkConflict: "2",
      checkCapacity: "2",
      queryContent: keyword
    };
    return { querySetting: JSON.stringify({ data, pageSize: "100", pageNumber: "0", order: "" }) };
  };

  const queryCategory = async (keyword, categoryCode) => {
    const meta = categoryMeta[categoryCode];
    const tab = document.getElementById(meta.tabId);
    if (!tab || tab.hasAttribute("disabled")) return { skipped: true, dataList: [] };
    const queryParam = buildQueryParam(keyword, categoryCode);
    let request;
    if (meta.queryKind === "recommended" && typeof window.queryRecommendedCourse === "function") {
      request = window.queryRecommendedCourse(queryParam);
    } else if (meta.queryKind === "public" && typeof window.queryPublicCourse === "function") {
      request = window.queryPublicCourse(queryParam);
    } else if (typeof window.queryProgramCourse === "function") {
      request = window.queryProgramCourse(queryParam);
    } else {
      throw new Error(`${meta.label}查询接口未加载`);
    }
    const response = await fromDeferred(request);
    if (String(response?.code) === "302") throw new Error("LOGIN_REQUIRED");
    if (String(response?.code) !== "1") throw new Error(response?.msg || `${meta.label}查询失败`);
    return { skipped: false, dataList: Array.isArray(response.dataList) ? response.dataList : [] };
  };

  const normalizeSection = (course, section, categoryCode) => {
    const item = section || course;
    const classCapacity = Number(item.classCapacity ?? 0);
    const selected = Number(item.numberOfFirstVolunteer ?? item.numberOfSelected ?? 0);
    return {
      courseName: normalizeText(course.courseName || item.courseName),
      courseNumber: normalizeText(course.courseNumber || item.courseNumber),
      categoryCode,
      categoryLabel: categoryMeta[categoryCode].label,
      teachingClassId: normalizeText(item.teachingClassID || item.teachingClassId),
      teacherName: normalizeText(item.teacherName) || "教师未安排",
      courseIndex: normalizeText(item.courseIndex) || "未标注",
      teachingPlace: normalizeText(item.teachingPlace) || "时间地点未安排",
      hasTest: normalizeText(item.hasTest || "0"),
      capacitySuffix: normalizeText(item.capacitySuffix),
      classCapacity,
      numberOfSelected: selected,
      isFull: normalizeText(item.isFull || (selected >= classCapacity ? "1" : "0")),
      isConflict: normalizeText(item.isConflict || "0"),
      isChoose: normalizeText(item.isChoose || course.isChoose || "0"),
      canOperate: normalizeText(item.canOperate || "1"),
      limitGender: normalizeText(item.limitGender || "0"),
      retakeType: normalizeText(item.retakeType),
      retakeTypeDetail: normalizeText(item.retakeTypeDetail),
      campus: normalizeText(item.campus),
      teachCampus: normalizeText(item.teachCampus),
      bookUnsupported: bookParam.canSelectBook === "1"
    };
  };

  if (action === "RESOLVE") {
    const keywords = Array.isArray(payload?.keywords) ? payload.keywords.map(normalizeText).filter(Boolean) : [];
    const output = [];
    const errors = [];
    for (const keyword of keywords) {
      const matches = [];
      for (const categoryCode of Object.keys(categoryMeta)) {
        try {
          const response = await queryCategory(keyword, categoryCode);
          for (const course of response.dataList) {
            const name = normalizeText(course.courseName);
            const number = normalizeText(course.courseNumber);
            if (name !== keyword && number !== keyword) continue;
            if (Array.isArray(course.tcList) && course.tcList.length > 0) {
              for (const section of course.tcList) matches.push(normalizeSection(course, section, categoryCode));
            } else {
              matches.push(normalizeSection(course, course, categoryCode));
            }
          }
        } catch (error) {
          if (error?.message === "LOGIN_REQUIRED") return failure("LOGIN_REQUIRED", "登录状态已失效", true);
          errors.push(`${categoryMeta[categoryCode].label}：${error?.message || error}`);
        }
      }
      output.push({ keyword, matches });
    }
    return { ok: true, groups: output, errors };
  }

  if (action === "RESOLVE_TEST") {
    if (typeof window.queryTestCourse !== "function") return failure("API_MISSING", "实验班查询接口未加载", true);
    const queryParam = {
      jxbid: payload.teachingClassId,
      electiveBatchCode: studentInfo.electiveBatch.code,
      studentCode: studentInfo.code,
      isMajor: categoryMeta[payload.categoryCode]?.isMajor || "1",
      teachingClassType: payload.categoryCode,
      campus: currentCampus.code,
      checkCapacity: "0",
      checkConflict: "0"
    };
    const response = await fromDeferred(window.queryTestCourse(queryParam));
    if (String(response?.code) === "302") return failure("LOGIN_REQUIRED", "登录状态已失效", true);
    if (String(response?.code) !== "1") return failure("QUERY_FAILED", response?.msg || "实验班查询失败");
    const course = Array.isArray(response.dataList) ? response.dataList[0] : null;
    const classes = (course?.tcList || []).map((item) => ({
      teachingClassId: normalizeText(item.teachingClassID || item.teachingClassId),
      teacherName: normalizeText(item.teacherName) || "教师未安排",
      courseIndex: normalizeText(item.courseIndex) || "未标注",
      teachingPlace: normalizeText(item.teachingPlace) || "时间地点未安排",
      classCapacity: Number(item.classCapacity ?? 0),
      numberOfSelected: Number(item.numberOfSelected ?? 0),
      selectable: item.isConflict !== "1" && item.isLimitKind !== "1" && item.isFull !== "1" && item.extInfo !== "1"
    }));
    return { ok: true, classes };
  }

  if (action === "CAPACITY") {
    if (typeof window.queryTeachingClassCapacity !== "function") return failure("API_MISSING", "容量查询接口未加载", true);
    const response = await fromDeferred(window.queryTeachingClassCapacity(payload.teachingClassId, studentInfo.code, payload.capacitySuffix || ""));
    if (String(response?.code) === "302") return failure("LOGIN_REQUIRED", "登录状态已失效", true);
    if (String(response?.code) !== "1" || !response.data) return failure("QUERY_FAILED", response?.msg || "容量查询失败", false, true);
    const data = response.data;
    let genderAllowed = true;
    let genderReason = "";
    if (String(data.limitGender) === "1") {
      if (String(studentInfo.gender) === "1") {
        genderAllowed = Number(data.numberOfMale ?? 0) + 1 <= Number(data.capacityOfMale ?? 0);
        genderReason = "男生容量已满";
      } else {
        genderAllowed = Number(data.numberOfFemale ?? 0) + 1 <= Number(data.capacityOfFemale ?? 0);
        genderReason = "女生容量已满";
      }
    }
    return {
      ok: true,
      data: {
        numberOfSelected: Number(data.numberOfSelected ?? 0),
        classCapacity: Number(data.classCapacity ?? 0),
        genderAllowed,
        genderReason
      }
    };
  }

  if (action === "SUBMIT") {
    if (bookParam.canSelectBook === "1") return failure("BOOK_UNSUPPORTED", "该轮次要求选择教材订购方式，扩展已阻止自动提交", true);
    if (typeof window.addVolunteer !== "function") return failure("API_MISSING", "选课提交接口未加载", true);
    if (String(payload.isChoose) === "1") return { ok: true, alreadySelected: true };
    if (String(payload.isConflict) === "1") {
      const allowed = (payload.retakeTypeDetail === "3" && currentBatch.refreshNoCheckTimeConflict === "1") ||
        (["02", "03"].includes(payload.retakeType) && currentBatch.retakeNoCheckTimeConflict === "1") ||
        currentBatch.noCheckTimeConflict === "1";
      if (!allowed) return failure("CONFLICT", "网站判定该班级存在时间冲突", true);
    }
    if (typeof window.queryXklcSfkfBySync === "function") {
      const opened = window.queryXklcSfkfBySync({ xklcdm: studentInfo.electiveBatch.code });
      if (String(opened?.msg) !== "1") return failure("ROUND_CLOSED", "当前选课轮次未开放", false, true);
    }
    const data = {
      operationType: "1",
      studentCode: studentInfo.code,
      electiveBatchCode: studentInfo.electiveBatch.code,
      teachingClassId: payload.teachingClassId,
      isMajor: "1",
      campus: currentCampus.code,
      teachingClassType: payload.categoryCode
    };
    if (payload.testTeachingClassId) data.testTeachingClassID = payload.testTeachingClassId;
    const response = await fromDeferred(window.addVolunteer({ addParam: JSON.stringify({ data }) }));
    if (String(response?.code) === "302") return failure("LOGIN_REQUIRED", "登录状态已失效", true);
    if (String(response?.code) !== "1") {
      const message = normalizeText(response?.msg) || "学校系统拒绝了选课请求";
      return failure("SUBMIT_REJECTED", message, false, /容量|已满|繁忙|稍后|轮次/.test(message));
    }
    return { ok: true };
  }

  if (action === "SUBMIT_STATUS") {
    if (typeof window.queryOperateProcess !== "function") return failure("API_MISSING", "提交状态接口未加载", true);
    const response = await fromDeferred(window.queryOperateProcess());
    if (String(response?.code) === "302") return failure("LOGIN_REQUIRED", "登录状态已失效", true);
    return { ok: true, code: normalizeText(response?.code), message: normalizeText(response?.msg) };
  }

  return failure("UNKNOWN_ACTION", `不支持的页面操作：${action}`, true);
}

async function safeNotify(title, message) {
  try {
    await chrome.notifications.create({
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon128.png"),
      title: redact(title),
      message: redact(message)
    });
    return true;
  } catch (error) {
    await addLog("warning", `系统通知发送失败：${safeMessage(error)}`).catch(() => {});
    return false;
  }
}

function formatScheduleRange(settings) {
  const overnight = settings.end <= settings.start ? "（次日结束）" : "";
  return `${settings.start}–${settings.end}${overnight}`;
}

function safeMessage(error) {
  return redact(error?.message || String(error || "未知错误"));
}

function redact(value) {
  return String(value || "")
    .replace(/([?&]token=)[^&\s]+/gi, "$1[已隐藏]")
    .replace(/("token"\s*:\s*")[^"]+/gi, "$1[已隐藏]");
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

void ensureDefaults()
  .then(async () => {
    await rescheduleDailyAlarms();
    await syncAlertBadge();
  })
  .catch(() => {});
