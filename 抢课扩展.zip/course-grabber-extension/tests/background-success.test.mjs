import assert from "node:assert/strict";

const listeners = {};
const event = (name) => ({ addListener(fn) { listeners[name] = fn; } });
const localStore = new Map();
const sessionStore = new Map();
let submitCalls = 0;
let releaseCalls = 0;
let siteMode = "success";
let badgeText = "";

const storageArea = (store) => ({
  async get(keys) {
    const names = Array.isArray(keys) ? keys : [keys];
    return Object.fromEntries(names.filter(Boolean).map((name) => [name, store.get(name)]));
  },
  async set(values) {
    Object.entries(values).forEach(([key, value]) => store.set(key, value));
  }
});

globalThis.chrome = {
  action: {
    onClicked: event("action"),
    setBadgeBackgroundColor: async () => {},
    setBadgeText: async ({ text }) => { badgeText = text; },
    setTitle: async () => {}
  },
  runtime: {
    onInstalled: event("installed"),
    onStartup: event("startup"),
    onMessage: event("message"),
    openOptionsPage: async () => {},
    sendMessage: async () => {},
    getURL: (path) => `chrome-extension://test/${path}`
  },
  alarms: {
    onAlarm: event("alarm"),
    clear: async () => true,
    create: async () => {}
  },
  storage: {
    local: storageArea(localStore),
    session: storageArea(sessionStore)
  },
  power: {
    requestKeepAwake() {},
    releaseKeepAwake() { releaseCalls += 1; }
  },
  notifications: {
    async create() {
      throw new Error("Unable to download all specified images.");
    }
  },
  tabs: {
    query: async () => [{
      id: 1,
      windowId: 1,
      active: true,
      title: "选课",
      url: "https://xsxk.nnu.edu.cn/xsxkapp/sys/xsxkapp/elective/grablessons.do"
    }],
    update: async () => {}
  },
  windows: { update: async () => {} },
  scripting: {
    async executeScript({ args }) {
      const action = args[0];
      if (action === "PING") return [{ result: { ready: true } }];
      if (action === "CAPACITY") {
        if (siteMode === "fatal") {
          return [{ result: { ok: false, fatal: true, code: "API_MISSING", message: "容量查询接口未加载" } }];
        }
        return [{ result: { ok: true, data: { numberOfSelected: 1, classCapacity: 2, genderAllowed: true } } }];
      }
      if (action === "SUBMIT") {
        submitCalls += 1;
        return [{ result: { ok: true } }];
      }
      if (action === "SUBMIT_STATUS") return [{ result: { ok: true, code: "1", message: "成功" } }];
      throw new Error(`未模拟页面操作：${action}`);
    }
  }
};

await import(`../background.js?success-test=${Date.now()}`);
await new Promise((resolve) => setTimeout(resolve, 30));

const call = (type, extra = {}) => new Promise((resolve, reject) => {
  const timeout = setTimeout(() => reject(new Error(`${type} 响应超时`)), 1000);
  listeners.message({ type, ...extra }, {}, (response) => {
    clearTimeout(timeout);
    if (response?.ok) resolve(response);
    else reject(new Error(response?.error || `${type} 调用失败`));
  });
});

const target = {
  id: "target-1",
  courseName: "无机化学选讲",
  courseNumber: "1008000099",
  categoryCode: "TJKC",
  teachingClassId: "class-1",
  teacherName: "吴勇",
  courseIndex: "01",
  hasTest: "0",
  capacitySuffix: "",
  state: "pending",
  isChoose: "0"
};

await call("SAVE_TARGETS", { targets: [target] });
const savedSchedule = await call("SAVE_SCHEDULE", { start: "23:55:00", end: "00:15:00" });
assert.equal(savedSchedule.settings.prepare, "23:54:55");
assert.equal(savedSchedule.settings.start, "23:55:00");
assert.equal(savedSchedule.settings.end, "00:15:00");
await call("START_MANUAL");
await new Promise((resolve) => setTimeout(resolve, 120));

let state = await call("GET_STATE");
assert.equal(state.targets[0].state, "success", "通知失败不能回退成功状态");
assert.equal(state.runtime.mode, "idle", "全部成功后应立即停止监控");
assert.equal(state.settings.enabled, false, "全部成功后每日自动任务应停用");
assert.equal(submitCalls, 1, "成功课程不得重复提交");
assert.ok(releaseCalls >= 1, "全部成功后应释放防休眠");
assert.equal(state.logs.some((log) => log.message.includes("提交异常")), false);
assert.equal(state.logs.some((log) => log.message.includes("系统通知发送失败")), true);

const secondStart = await call("START_MANUAL");
assert.equal(secondStart.allSuccessful, true, "所有目标成功后不应再次启动");
await new Promise((resolve) => setTimeout(resolve, 30));
state = await call("GET_STATE");
assert.equal(state.runtime.mode, "idle");
assert.equal(submitCalls, 1);

await call("RESET_RESULTS");
siteMode = "fatal";
await call("START_MANUAL");
await new Promise((resolve) => setTimeout(resolve, 80));
state = await call("GET_STATE");
assert.equal(state.targets[0].state, "blocked");
assert.equal(state.alerts.length, 1, "永久失败应生成持久告警");
assert.match(state.alerts[0].message, /接口未加载/);
assert.equal(badgeText, "!", "永久失败应显示扩展红色角标");

await call("ACK_ALERT");
state = await call("GET_STATE");
assert.equal(state.alerts.length, 0, "确认后应清除告警");
assert.equal(state.targets[0].state, "blocked", "确认告警不能清除失败状态");
assert.equal(badgeText, "", "确认告警后应清除扩展角标");

console.log("成功收尾与通知隔离回归测试通过");
