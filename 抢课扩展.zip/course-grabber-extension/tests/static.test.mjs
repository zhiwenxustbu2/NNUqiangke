import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const manifest = JSON.parse(await readFile(resolve(root, "manifest.json"), "utf8"));
const dashboardHtml = await readFile(resolve(root, "dashboard.html"), "utf8");
const dashboardJs = await readFile(resolve(root, "dashboard.js"), "utf8");
const backgroundJs = await readFile(resolve(root, "background.js"), "utf8");

assert.equal(manifest.manifest_version, 3);
assert.equal(manifest.background.type, "module");
assert.equal(manifest.version, "1.1.0");
assert.deepEqual(manifest.host_permissions, ["https://xsxk.nnu.edu.cn/*"]);

for (const path of [manifest.background.service_worker, manifest.options_page]) {
  await readFile(resolve(root, path));
}

for (const path of Object.values(manifest.icons)) {
  const icon = await readFile(resolve(root, path));
  assert.equal(icon.subarray(1, 4).toString("ascii"), "PNG", `${path} 不是有效 PNG`);
}

const ids = [...dashboardJs.matchAll(/getElementById\("([^"]+)"\)/g)].map((match) => match[1]);
for (const id of ids) {
  assert.match(dashboardHtml, new RegExp(`id=["']${id}["']`), `dashboard.html 缺少 #${id}`);
}

assert.equal(/<script(?![^>]+src=)/i.test(dashboardHtml), false, "不应使用内联脚本");
assert.equal(/on(click|change|submit)=/i.test(dashboardHtml), false, "不应使用内联事件处理器");
assert.equal(/location\.reload\s*\(/.test(backgroundJs), false, "容量监控不应整页刷新");
assert.equal(/data:image\/svg\+xml/.test(backgroundJs), false, "系统通知不应继续使用 data SVG 图标");

console.log("扩展静态结构测试通过");
