import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const manifest = JSON.parse(await readFile(resolve(root, "manifest.json"), "utf8"));
const dashboardHtml = await readFile(resolve(root, "dashboard.html"), "utf8");
const dashboardJs = await readFile(resolve(root, "dashboard.js"), "utf8");

assert.equal(manifest.manifest_version, 3);
assert.equal(manifest.background.type, "module");
assert.deepEqual(manifest.host_permissions, ["https://xsxk.nnu.edu.cn/*"]);

for (const path of [manifest.background.service_worker, manifest.options_page]) {
  await readFile(resolve(root, path));
}

const ids = [...dashboardJs.matchAll(/getElementById\("([^"]+)"\)/g)].map((match) => match[1]);
for (const id of ids) {
  assert.match(dashboardHtml, new RegExp(`id=["']${id}["']`), `dashboard.html 缺少 #${id}`);
}

assert.equal(/<script(?![^>]+src=)/i.test(dashboardHtml), false, "不应使用内联脚本");
assert.equal(/on(click|change|submit)=/i.test(dashboardHtml), false, "不应使用内联事件处理器");

console.log("扩展静态结构测试通过");
