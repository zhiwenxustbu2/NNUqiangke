import {
  CATEGORY_META,
  RUNTIME_MODES,
  TARGET_STATES,
  sanitizeTargetForExport,
  targetValidationError
} from "./core.js";

const els = {
  runtimeBadge: document.getElementById("runtimeBadge"),
  runtimeDetails: document.getElementById("runtimeDetails"),
  autoEnabled: document.getElementById("autoEnabled"),
  dryRunButton: document.getElementById("dryRunButton"),
  manualStartButton: document.getElementById("manualStartButton"),
  stopButton: document.getElementById("stopButton"),
  resetButton: document.getElementById("resetButton"),
  searchForm: document.getElementById("searchForm"),
  searchButton: document.getElementById("searchButton"),
  courseKeywords: document.getElementById("courseKeywords"),
  cancelEditButton: document.getElementById("cancelEditButton"),
  searchResults: document.getElementById("searchResults"),
  targetTableBody: document.getElementById("targetTableBody"),
  targetEmpty: document.getElementById("targetEmpty"),
  exportButton: document.getElementById("exportButton"),
  importInput: document.getElementById("importInput"),
  logList: document.getElementById("logList"),
  testClassDialog: document.getElementById("testClassDialog"),
  testClassSelect: document.getElementById("testClassSelect"),
  confirmTestClassButton: document.getElementById("confirmTestClassButton"),
  toast: document.getElementById("toast")
};

let state = { settings: {}, targets: [], runtime: {}, logs: [] };
let searchGroups = [];
let editingTargetId = null;
let pendingTheoryTarget = null;
let toastTimer = null;
let refreshTimer = null;

els.searchForm.addEventListener("submit", handleSearch);
els.cancelEditButton.addEventListener("click", cancelEdit);
els.dryRunButton.addEventListener("click", runDryCheck);
els.manualStartButton.addEventListener("click", startManual);
els.stopButton.addEventListener("click", stopMonitoring);
els.resetButton.addEventListener("click", resetResults);
els.autoEnabled.addEventListener("change", toggleAuto);
els.exportButton.addEventListener("click", exportConfig);
els.importInput.addEventListener("change", importConfig);
els.confirmTestClassButton.addEventListener("click", confirmTestClass);
els.targetTableBody.addEventListener("click", handleTargetAction);
els.searchResults.addEventListener("click", handleResultAction);

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "STATE_CHANGED") scheduleRefresh();
});

document.addEventListener("visibilitychange", () => {
  if (!document.hidden) void refreshState();
});

await refreshState();
setInterval(() => {
  if (!document.hidden) void refreshState(false);
}, 1000);

async function call(type, extra = {}) {
  const response = await chrome.runtime.sendMessage({ type, ...extra });
  if (!response?.ok) throw new Error(response?.error || "扩展后台没有响应");
  return response;
}

async function refreshState(showError = true) {
  try {
    state = await call("GET_STATE");
    render();
  } catch (error) {
    if (showError) showToast(error.message, true);
  }
}

function scheduleRefresh() {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => void refreshState(false), 80);
}

function render() {
  renderRuntime();
  renderTargets();
  renderLogs();
  els.autoEnabled.checked = Boolean(state.settings.enabled);
}

function renderRuntime() {
  const mode = state.runtime.mode || RUNTIME_MODES.IDLE;
  const labels = {
    [RUNTIME_MODES.IDLE]: "未运行",
    [RUNTIME_MODES.DRY_RUN]: "演练中",
    [RUNTIME_MODES.MANUAL]: "手动运行中",
    [RUNTIME_MODES.SCHEDULED]: "自动运行中",
    [RUNTIME_MODES.STOPPING]: "正在停止"
  };
  els.runtimeBadge.textContent = labels[mode] || mode;
  els.runtimeBadge.className = `runtime-badge ${mode === RUNTIME_MODES.IDLE ? "idle" : mode === RUNTIME_MODES.DRY_RUN ? "dry" : "running"}`;
  const running = [RUNTIME_MODES.MANUAL, RUNTIME_MODES.SCHEDULED].includes(mode);
  els.manualStartButton.disabled = running;
  els.dryRunButton.disabled = running || mode === RUNTIME_MODES.DRY_RUN;
  els.stopButton.disabled = !running;
  els.resetButton.disabled = running;

  const active = state.targets.find((target) => target.id === state.runtime.activeTargetId);
  const started = state.runtime.startedAt ? formatDateTime(state.runtime.startedAt) : "—";
  const checked = state.runtime.lastCheckAt ? formatDateTime(state.runtime.lastCheckAt) : "—";
  const backoff = state.runtime.backoffUntil > Date.now() ? `；退避至 ${formatDateTime(state.runtime.backoffUntil)}` : "";
  els.runtimeDetails.textContent = `启动时间：${started}　当前目标：${active ? `${active.courseName} [${active.courseIndex}]` : "—"}　最近检查：${checked}${backoff}`;
}

function renderTargets() {
  els.targetTableBody.replaceChildren();
  els.targetEmpty.classList.toggle("hidden", state.targets.length > 0);
  for (const target of state.targets) {
    const row = document.createElement("tr");
    const capacity = target.lastCapacity ? `${target.lastCapacity.selected}/${target.lastCapacity.capacity}` : `${target.numberOfSelected ?? "—"}/${target.classCapacity ?? "—"}`;
    const status = targetStateLabel(target.state);
    row.innerHTML = `
      <td><strong>${escapeHtml(target.courseName)}</strong><div class="subtle">${escapeHtml(target.courseNumber)}</div></td>
      <td>${escapeHtml(CATEGORY_META[target.categoryCode]?.label || target.categoryLabel || target.categoryCode)}</td>
      <td><strong>[${escapeHtml(target.courseIndex)}] ${escapeHtml(target.teacherName)}</strong><div class="subtle">${escapeHtml(target.teachingPlace || "")}</div></td>
      <td>${escapeHtml(capacity)}</td>
      <td><span class="status-pill ${escapeHtml(target.state || "pending")}">${escapeHtml(status)}</span><div class="subtle">${escapeHtml(target.lastMessage || "等待监控")}</div></td>
      <td><div class="row-actions"><button class="button ghost small" data-action="edit" data-id="${escapeHtml(target.id)}">修改</button><button class="button ghost small" data-action="remove" data-id="${escapeHtml(target.id)}">删除</button></div></td>`;
    els.targetTableBody.append(row);
  }
}

function renderLogs() {
  els.logList.replaceChildren();
  if (state.logs.length === 0) {
    const item = document.createElement("li");
    item.className = "empty-state";
    item.textContent = "暂无运行日志";
    els.logList.append(item);
    return;
  }
  for (const log of state.logs.slice(0, 120)) {
    const item = document.createElement("li");
    item.className = "log-item";
    item.innerHTML = `<span class="log-time">${escapeHtml(formatDateTime(log.time))}</span><span class="log-level ${escapeHtml(log.level)}">${escapeHtml(logLevelLabel(log.level))}</span><span>${escapeHtml(log.message)}</span>`;
    els.logList.append(item);
  }
}

async function handleSearch(event) {
  event.preventDefault();
  const keywords = els.courseKeywords.value.split(/\r?\n/).map((item) => item.trim()).filter(Boolean);
  if (keywords.length === 0) return showToast("请至少输入一个课程名或课程号", true);
  setBusy(els.searchButton, true, "正在查询…");
  try {
    const response = await call("RESOLVE_COURSES", { keywords });
    if (!response.result?.ok) throw new Error(response.result?.message || "课程查询失败");
    searchGroups = response.result.groups || [];
    renderSearchResults(response.result.errors || []);
  } catch (error) {
    showToast(error.message, true);
  } finally {
    setBusy(els.searchButton, false, "查找可选班级");
  }
}

function renderSearchResults(errors) {
  els.searchResults.replaceChildren();
  els.searchResults.classList.remove("hidden");
  searchGroups.forEach((group, groupIndex) => {
    const wrapper = document.createElement("div");
    wrapper.className = "result-group";
    const title = document.createElement("h3");
    title.textContent = `“${group.keyword}”的精确匹配`;
    wrapper.append(title);
    if (!group.matches?.length) {
      const empty = document.createElement("div");
      empty.className = "result-error";
      empty.textContent = "未找到完全相同的课程名或课程号";
      wrapper.append(empty);
    } else {
      const row = document.createElement("div");
      row.className = "result-row";
      const select = document.createElement("select");
      select.dataset.groupIndex = String(groupIndex);
      group.matches.forEach((match, matchIndex) => {
        const option = document.createElement("option");
        option.value = String(matchIndex);
        option.textContent = `${match.categoryLabel}｜${match.courseNumber}｜[${match.courseIndex}] ${match.teacherName}｜${match.teachingPlace}｜${match.numberOfSelected}/${match.classCapacity}`;
        select.append(option);
      });
      const button = document.createElement("button");
      button.type = "button";
      button.className = "button primary";
      button.dataset.action = "add-result";
      button.dataset.groupIndex = String(groupIndex);
      button.textContent = editingTargetId ? "保存这个班级" : "添加这个班级";
      row.append(select, button);
      wrapper.append(row);
    }
    els.searchResults.append(wrapper);
  });
  if (errors.length > 0) {
    const warning = document.createElement("p");
    warning.className = "result-error";
    warning.textContent = `部分栏目查询失败：${errors.join("；")}`;
    els.searchResults.append(warning);
  }
}

async function handleResultAction(event) {
  const button = event.target.closest("button[data-action='add-result']");
  if (!button) return;
  const groupIndex = Number(button.dataset.groupIndex);
  const select = els.searchResults.querySelector(`select[data-group-index="${groupIndex}"]`);
  const match = searchGroups[groupIndex]?.matches?.[Number(select?.value)];
  if (!match) return showToast("请选择一个具体班级", true);
  if (match.hasTest === "1") {
    setBusy(button, true, "查询实验班…");
    try {
      const response = await call("RESOLVE_TEST_CLASSES", { target: match });
      if (!response.result?.ok) throw new Error(response.result?.message || "实验班查询失败");
      const selectable = (response.result.classes || []).filter((item) => item.selectable);
      if (selectable.length === 0) throw new Error("该课程没有可指定的实验班");
      pendingTheoryTarget = match;
      els.testClassSelect.replaceChildren();
      for (const item of selectable) {
        const option = document.createElement("option");
        option.value = item.teachingClassId;
        option.dataset.class = JSON.stringify(item);
        option.textContent = `[${item.courseIndex}] ${item.teacherName}｜${item.teachingPlace}｜${item.numberOfSelected}/${item.classCapacity}`;
        els.testClassSelect.append(option);
      }
      els.testClassDialog.showModal();
    } catch (error) {
      showToast(error.message, true);
    } finally {
      setBusy(button, false, editingTargetId ? "保存这个班级" : "添加这个班级");
    }
    return;
  }
  await saveResolvedTarget(match);
}

async function confirmTestClass(event) {
  event.preventDefault();
  const option = els.testClassSelect.selectedOptions[0];
  if (!pendingTheoryTarget || !option) return;
  const testClass = JSON.parse(option.dataset.class);
  await saveResolvedTarget({
    ...pendingTheoryTarget,
    testTeachingClassId: testClass.teachingClassId,
    testTeacherName: testClass.teacherName,
    testCourseIndex: testClass.courseIndex
  });
  pendingTheoryTarget = null;
  els.testClassDialog.close();
}

async function saveResolvedTarget(match) {
  const target = {
    ...match,
    id: editingTargetId || crypto.randomUUID(),
    state: TARGET_STATES.PENDING,
    resolvedAt: Date.now(),
    lastMessage: "等待监控",
    lastCapacity: { selected: match.numberOfSelected, capacity: match.classCapacity }
  };
  let targets = [...state.targets];
  const duplicateIndex = targets.findIndex((item) => item.teachingClassId === target.teachingClassId && item.id !== editingTargetId);
  if (duplicateIndex >= 0) return showToast("该教学班已经在目标列表中", true);
  if (editingTargetId) {
    const index = targets.findIndex((item) => item.id === editingTargetId);
    if (index >= 0) targets[index] = target;
    else targets.push(target);
  } else {
    targets.push(target);
  }
  await call("SAVE_TARGETS", { targets });
  cancelEdit();
  await refreshState();
  showToast(`已添加 ${target.courseName} [${target.courseIndex}]`);
}

async function handleTargetAction(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const target = state.targets.find((item) => item.id === button.dataset.id);
  if (!target) return;
  if (button.dataset.action === "remove") {
    if (!confirm(`删除目标课程“${target.courseName} [${target.courseIndex}]”吗？`)) return;
    await call("SAVE_TARGETS", { targets: state.targets.filter((item) => item.id !== target.id) });
    await refreshState();
    return;
  }
  if (button.dataset.action === "edit") {
    editingTargetId = target.id;
    els.courseKeywords.value = target.courseNumber || target.courseName;
    els.cancelEditButton.classList.remove("hidden");
    els.searchButton.textContent = "重新查找班级";
    els.courseKeywords.focus();
    window.scrollTo({ top: els.searchForm.offsetTop - 80, behavior: "smooth" });
  }
}

function cancelEdit() {
  editingTargetId = null;
  searchGroups = [];
  els.courseKeywords.value = "";
  els.searchResults.classList.add("hidden");
  els.searchResults.replaceChildren();
  els.cancelEditButton.classList.add("hidden");
  els.searchButton.textContent = "查找可选班级";
}

async function runDryCheck() {
  const error = firstValidationError();
  if (error) return showToast(error, true);
  setBusy(els.dryRunButton, true, "演练中…");
  try {
    const response = await call("DRY_RUN");
    const success = response.checked.filter((item) => item.ok).length;
    showToast(`演练完成：${success}/${response.checked.length} 个目标读取成功，未提交选课`);
    await refreshState();
  } catch (errorValue) {
    showToast(errorValue.message, true);
  } finally {
    setBusy(els.dryRunButton, false, "演练检查");
  }
}

async function startManual() {
  const error = firstValidationError();
  if (error) return showToast(error, true);
  if (!confirm(buildConfirmation("立即开始手动监控，不受 17:15 限制，直到全部成功或手动停止。"))) return;
  setBusy(els.manualStartButton, true, "正在启动…");
  try {
    await call("START_MANUAL");
    showToast("手动监控已启动");
    await refreshState();
  } catch (errorValue) {
    showToast(errorValue.message, true);
  } finally {
    setBusy(els.manualStartButton, false, "立即开始监控");
  }
}

async function stopMonitoring() {
  if (!confirm("确定停止当前监控吗？已成功的课程记录会保留。")) return;
  try {
    await call("STOP");
    await refreshState();
  } catch (error) {
    showToast(error.message, true);
  }
}

async function resetResults() {
  if (!confirm("将所有目标恢复为“等待监控”，确定继续吗？")) return;
  await call("RESET_RESULTS");
  await refreshState();
}

async function toggleAuto() {
  const enabled = els.autoEnabled.checked;
  if (enabled) {
    const error = firstValidationError();
    if (error || !confirm(buildConfirmation("启用每天北京时间 16:55–17:15 自动监控。"))) {
      els.autoEnabled.checked = false;
      if (error) showToast(error, true);
      return;
    }
  }
  try {
    await call("SET_AUTO_ENABLED", { enabled });
    showToast(enabled ? "已启用每日自动运行" : "已停用每日自动运行");
    await refreshState();
  } catch (error) {
    els.autoEnabled.checked = !enabled;
    showToast(error.message, true);
  }
}

function exportConfig() {
  const data = {
    version: 1,
    exportedAt: new Date().toISOString(),
    schedule: { enabled: false, start: "16:55:00", end: "17:15:00", timeZone: "Asia/Shanghai" },
    targets: state.targets.map(sanitizeTargetForExport)
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `选课监控配置-${new Date().toISOString().slice(0, 10)}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
}

async function importConfig(event) {
  const file = event.target.files?.[0];
  event.target.value = "";
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    if (!Array.isArray(parsed.targets)) throw new Error("配置文件中没有目标课程列表");
    const imported = parsed.targets.map((target) => ({
      ...target,
      id: crypto.randomUUID(),
      teachingClassId: "",
      testTeachingClassId: "",
      state: TARGET_STATES.BLOCKED,
      lastMessage: "来自其他电脑，请点击修改并重新解析班级",
      lastCapacity: null,
      needsResolve: true
    }));
    await call("SAVE_TARGETS", { targets: imported });
    await call("SET_AUTO_ENABLED", { enabled: false });
    await refreshState();
    showToast(`已导入 ${imported.length} 个目标；为防止学期班级 ID 变化，请逐项重新解析`);
  } catch (error) {
    showToast(`导入失败：${error.message}`, true);
  }
}

function firstValidationError() {
  if (state.targets.length === 0) return "请先添加至少一个目标课程";
  for (const target of state.targets) {
    const error = targetValidationError(target);
    if (error) return `${target.courseName || "目标课程"}：${error}`;
  }
  return "";
}

function buildConfirmation(prefix) {
  const lines = state.targets.map((target) => `• ${target.courseName}｜${CATEGORY_META[target.categoryCode]?.label || target.categoryCode}｜[${target.courseIndex}] ${target.teacherName}`);
  return `${prefix}\n\n将自动提交以下具体班级：\n${lines.join("\n")}\n\n请确认课程、老师和课序号无误。`;
}

function targetStateLabel(value) {
  return ({
    [TARGET_STATES.PENDING]: "等待监控",
    [TARGET_STATES.MONITORING]: "监控中",
    [TARGET_STATES.SUBMITTING]: "提交中",
    [TARGET_STATES.SUCCESS]: "已成功",
    [TARGET_STATES.BLOCKED]: "已停止"
  })[value] || "等待监控";
}

function logLevelLabel(value) {
  return ({ info: "信息", warning: "提醒", error: "错误", success: "成功" })[value] || value;
}

function formatDateTime(timestamp) {
  return new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  }).format(new Date(timestamp));
}

function setBusy(button, busy, text) {
  button.disabled = busy;
  button.textContent = text;
}

function showToast(message, isError = false) {
  clearTimeout(toastTimer);
  els.toast.textContent = message;
  els.toast.className = `toast show${isError ? " error" : ""}`;
  toastTimer = setTimeout(() => { els.toast.className = "toast"; }, 4200);
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    '"': "&quot;"
  })[char]);
}
