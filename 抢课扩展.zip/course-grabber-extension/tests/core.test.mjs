import assert from "node:assert/strict";
import {
  TARGET_STATES,
  backoffDelayMs,
  capacityDecision,
  isInScheduleWindow,
  nextBjtOccurrence,
  pickNextTarget,
  sanitizeTargetForExport,
  targetValidationError
} from "../core.js";

const bjtTimestamp = (dateText) => new Date(`${dateText}+08:00`).getTime();

assert.equal(isInScheduleWindow(bjtTimestamp("2026-08-24T16:54:59"), { start: "16:55:00", end: "17:15:00" }), false);
assert.equal(isInScheduleWindow(bjtTimestamp("2026-08-24T16:55:00"), { start: "16:55:00", end: "17:15:00" }), true);
assert.equal(isInScheduleWindow(bjtTimestamp("2026-08-24T17:14:59"), { start: "16:55:00", end: "17:15:00" }), true);
assert.equal(isInScheduleWindow(bjtTimestamp("2026-08-24T17:15:00"), { start: "16:55:00", end: "17:15:00" }), false);

assert.equal(nextBjtOccurrence("16:55:00", bjtTimestamp("2026-08-24T16:54:00")), bjtTimestamp("2026-08-24T16:55:00"));
assert.equal(nextBjtOccurrence("16:55:00", bjtTimestamp("2026-08-24T16:56:00")), bjtTimestamp("2026-08-25T16:55:00"));

assert.deepEqual([1, 2, 3, 4, 5, 6].map(backoffDelayMs), [2000, 4000, 8000, 16000, 30000, 30000]);

const targets = [
  { id: "a", state: TARGET_STATES.SUCCESS },
  { id: "b", state: TARGET_STATES.MONITORING },
  { id: "c", state: TARGET_STATES.PENDING }
];
assert.deepEqual(pickNextTarget(targets, 0), { target: targets[1], nextIndex: 2 });
assert.deepEqual(pickNextTarget(targets, 2), { target: targets[2], nextIndex: 0 });

assert.deepEqual(capacityDecision({ numberOfSelected: 36, classCapacity: 70, genderAllowed: true }), {
  available: true,
  selected: 36,
  capacity: 70,
  reason: "可选"
});
assert.equal(capacityDecision({ numberOfSelected: 70, classCapacity: 70, genderAllowed: true }).available, false);
assert.equal(capacityDecision({ numberOfSelected: 30, classCapacity: 70, genderAllowed: false, genderReason: "女生容量已满" }).reason, "女生容量已满");

const validTarget = {
  courseName: "无机化学选讲",
  courseNumber: "1008000099",
  categoryCode: "TJKC",
  teachingClassId: "class-id",
  teacherName: "吴勇",
  courseIndex: "01",
  hasTest: "0"
};
assert.equal(targetValidationError(validTarget), "");
assert.match(targetValidationError({ ...validTarget, teachingClassId: "" }), /老师和课序号/);
assert.match(targetValidationError({ ...validTarget, hasTest: "1" }), /实验班/);
assert.match(targetValidationError({ ...validTarget, bookUnsupported: true }), /教材/);

const exported = sanitizeTargetForExport({ ...validTarget, state: "success", lastMessage: "选课成功", lastCapacity: { selected: 1, capacity: 2 } });
assert.equal("state" in exported, false);
assert.equal("lastMessage" in exported, false);
assert.equal(exported.courseNumber, "1008000099");

console.log("核心逻辑测试全部通过");
